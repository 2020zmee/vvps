<?php
error_reporting(0);
header('Content-Type: application/json');
/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/
function GetURL($url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    return curl_exec($ch);
}

if(isset($_GET['id'])){
	$get = GetURL("https://www.instagram.com/".$_GET['id']."/");
	
	preg_match_all('/<script\stype="text\/javascript">window\.\_sharedData\s=\s(.*)/', $get, $match);
	echo str_replace(";</script>", null, $match[1][0]);
}else{
	echo json_encode(['ok'=>false,'description'=>"Error Complate Parameter !"]);
}

?>