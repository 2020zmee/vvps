<?php
/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/
ob_start();
error_reporting(0);
include('database.php');
##----------[Bot Method]----------##
function Project($method, $datas = []){
    $url = 'https://api.telegram.org/bot'.API_KEY.'/'.$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
##----------[Functions]----------##
function Send($from_id,$text,$pars,$webpage){
    Project('sendMessage',['chat_id'=>$from_id,'text'=>$text,'parse_mode'=>$pars,'disable_web_page_preview'=>$webpage]);
}
##----------[Codes]----------##
$Amount = $_GET['amount'];
$Authority = $_GET['Authority'];
$user = $_GET['id'];
if($_GET['Status'] == 'OK'){
    $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
    $result = $client->PaymentVerification(['MerchantID' => $MerchantID,'Authority' => $Authority,'Amount' => $Amount,]);
    if($result->Status == 100){
        $data = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `users` WHERE `userid` = '$user'"));
        $followers = $data['followers'];
        // pack 1 follower
        if($Amount == '700'){
            $flwo = $followers + 100;
            $connect->query("UPDATE `users` SET `followers` = '$flwo'  WHERE `userid` = '$user'");
            $textok = "پرداخت شما با موفقیت انجام شد🏧
💸هزینه پرداخت شده : $Amount
به حساب شما مقدار $flwo فالوور واریز شد✅

ممنون بابت خرید شما🌀";
            Send($user,$textok,'html',true);
            $textpay = "یک خرید بسته فالوور با موفقیت انجام شد ✅
💸 مقدار هزینه پرداخت شده : $Amount

پیوی کاربر : <a href='tg://user?id=$user'><$user</a>";
            Send($admins[0],$textpay,'html',true);
        }
        // pack 1 likes
        if($Amount == '400'){
            $lke = $likes + 100;
            $connect->query("UPDATE `users` SET `likes` = '$lke'  WHERE `userid` = '$user';");
            $textok = "پرداخت شما با موفقیت انجام شد🏧
💸هزینه پرداخت شده : $Amount
به حساب شما مقدار $flwo لایک واریز شد✅

ممنون بابت خرید شما🌀";
            Send($user,$textok,'html',true);
            $textpay = "یک خرید بسته لایک با موفقیت انجام شد ✅
💸 مقدار هزینه پرداخت شده : $Amount

پیوی کاربر : <a href='tg://user?id=$user'><$user</a>";
            Send($admins[0],$textpay,'html',true);
        }
    } else {
        echo 'پرداخت شما قبلا ثبت شده است';
    }
} else {
    echo 'پرداخت انجام نشد';
}

echo '<meta http-equiv="refresh" content="10;https://t.me/$kanal[0]">';

?>