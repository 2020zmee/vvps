<?php
// اسکریپت ساخت دیتابیس
ob_start();
include('database.php');

$connect->query("CREATE TABLE `users` (`userid` int(32) PRIMARY KEY,`phone` bigint(12) NOT NULL,`command` text NOT NULL,`free_likes` int(5) NOT NULL,`free_followers` int(5) NOT NULL,`likes` int(5) NOT NULL,`followers` int(5) NOT NULL,`block` text NOT NULL)");
$connect->query("CREATE TABLE `panel` (`power` text NULL)");
$connect->query("INSERT INTO `panel` (`power`) VALUES ('ON')");

echo 'database tables was created !';

/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/