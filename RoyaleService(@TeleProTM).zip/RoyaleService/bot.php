<?php
/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/
ob_start();
set_time_limit(300);
error_reporting(0);
include('database.php');
$connect->query('SET CHARACTER SET utf8mb4');
##----------[fake update]----------##
$telegram_ip_ranges = [['lower' => '149.154.160.0', 'upper' => '149.154.175.255'],['lower' => '91.108.4.0','upper' => '91.108.7.255']];
$ip_dec = (float) sprintf('%u', ip2long($_SERVER['REMOTE_ADDR']));$ok=false;
foreach ($telegram_ip_ranges as $telegram_ip_range) if (!$ok) {
$lower_dec = (float) sprintf('%u', ip2long($telegram_ip_range['lower']));
$upper_dec = (float) sprintf('%u', ip2long($telegram_ip_range['upper']));
if ($ip_dec >= $lower_dec and $ip_dec <= $upper_dec) $ok=true; }
if (!$ok) die("Hmm, I don't trust you...");
##----------[Bot Method]----------##
function Project($method, $datas = []){
    $url = 'https://api.telegram.org/bot'.API_KEY.'/'.$method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
##----------[Functions]----------##
function pay($from_id,$Amount,$tozih){
    $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
    global $MerchantID;
    $result = $client->PaymentRequest([
        'MerchantID' => $MerchantID,
        'Amount' => $Amount,
        'Description' => $tozih,
        'Email' => '',
        'Mobile' => '',
        'CallbackURL' => 'https://'.$_SERVER['HTTP_HOST'].str_replace('/index.php',null,$_SERVER['REQUEST_URI']).'/pay.php?id='.$from_id.'&amount='.$Amount
	]);
    if($result->Status == 100){
        return 'https://www.zarinpal.com/pg/StartPay/'.$result->Authority.'/ZarinGate';
    }
}
//===
function Send($from_id,$text,$pars,$webpage,$id,$key){
    Project('sendMessage',['chat_id'=>$from_id,'text'=>$text,'parse_mode'=>$pars,'disable_web_page_preview'=>$webpage,'reply_to_message_id'=>$id,'reply_markup'=>$key]);
}
##----------[System Variables]----------##
$update = json_decode(file_get_contents('php://input'));
$message = isset($update->message->text)?$update->message->text:$update->callback_query->data;
$from_id = isset($update->message->from->id)?$update->message->from->id:$update->callback_query->from->id;
$message_id = isset($update->message->message_id)?$update->message->message_id:$update->callback_query->message->message_id;
$first = $update->message->from->first_name;
##----------[SQL Variables]----------##
$users = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `users` WHERE `userid` = '$from_id'"));
$pnl = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `panel`"));
##----------[Lock Channel]----------##
if(!is_null($kanal[0])){
    $tch_1 = Project('getChatMember',['chat_id'=>$kanal[0],'user_id'=>$from_id])->result->status;
}if(!is_null($kanal[1])){
    $tch_2 = Project('getChatMember',['chat_id'=>$kanal[1],'user_id'=>$from_id])->result->status;
}
##----------[Buttons]----------##
$menu = json_encode(['keyboard'=>[[['text'=>'خدمات اینستاگرام 🦋 (رایگان)']],[['text'=>'خرید لایک اینستاگرام ❤️'],['text'=>'خرید فالوور اینستاگرام 👤']],[['text'=>'اطلاعات اکانت اینستاگرام🗄']],[['text'=>'زیرمجموعه گیری👨‍👧‍👦'],['text'=>'راهنما ⚠️'],['text'=>'پشتیبانی🗣']]],'resize_keyboard'=>true,'one_time_keyboard'=>true]);
$back = json_encode(['keyboard'=>[[['text'=>'➡️']]],'resize_keyboard'=>true,'one_time_keyboard'=>true]);
$back2 = json_encode(['keyboard'=>[[['text'=>'↪️']]],'resize_keyboard'=>true,'one_time_keyboard'=>true]);
$panel = json_encode(['keyboard'=>[[['text'=>'آمار📈']],[['text'=>'اطلاعات کاربر🔐']],[['text'=>'فوروارد📩'],['text'=>'ارسال🏮']],[['text'=>'بلاک💤'],['text'=>'آنبلاک☀️']],[['text'=>'روشن 📳'],['text'=>'خاموش 📴']],[['text'=>'➡️']]],'resize_keyboard'=>true,'one_time_keyboard'=>true]);
$remove = json_encode(['KeyboardRemove'=>[],'remove_keyboard'=>true]);
##----------[block and power]----------##
if($pnl['power'] == 'OFF' && !in_array($from_id,$admins)){
    Send($from_id,'ربات جهت بروزرسانی یا رفع مشکلات توسط مدیران خاموش شده است!',null,null,$message_id);
    exit();
}if($users['block'] == 'true' && !in_array($from_id,$admins)){
    Send($from_id,'🛑شما به خاطر رعایت نکردن قوانین از ربات مسدود شدید 

❇️ لطفا پیام دوباره ارسال نکنید',null,null,$remove);
    exit();
}if($from_id != isset($update->message->chat->id)?$update->message->chat->id:$update->callback_query->message->chat->id){
    Project('LeaveChat',['chat_id'=>isset($update->message->chat->id)?$update->message->chat->id:$update->callback_query->message->chat->id]);
}
##----------[Start]----------##
else if(preg_match('/^\/(start)/',$message) or $message == '➡️'){
    preg_match('/^\/(start inv_(.*))/',$message,$match);
    $match[2] = base64_decode(str_replace([' ',PHP_EOL,'inv_'],null,$match[2]));
    $unb = Project('getme')->result->username;
    $fnb = Project('getme')->result->first_name;
    if($match[2] != null){
        if($match[2] != $from_id){
            if($users['userid'] == false){
                if($users['phone'] == '0' || $users['phone'] == false){
                    Send($from_id,'برای تایید شماره شما جهت مقابله با کاربران فیک (مجازی) شماره خود را توسط کیبورد زیر به اشتراک بگذارید〽️
✳️ توجه : شماره شما نزد ما امن میماند و برای کسی فاش نمیشود‼️',null,null,$message_id,json_encode(['keyboard'=>[[['text'=>'تایید شماره +98 💯','request_contact'=>true]]],'resize_keyboard'=>true,'one_time_keyboard'=>true]));
                    $connect->query("INSERT INTO `users` (`userid`,`phone`,`command`,`free_likes`,`free_followers`,`likes`,`followers`,`block`) VALUES ('$from_id','0','phone confirm-$match[2]','50','20','0','0','false')");
                } else {
                    Send($from_id,"▪️کاربر <a href='tg://user?id=$from_id'>$first</a>\nبه ربات <a href='https://t.me/$unb'>$fnb</a> خوش آمدید🎗\n\nتوسط این ربات میتوانید از خدمات اینستاگرام #رایگان از جمله لایک و فالوور برخوردار شوید‼️",'html',true,$message_id,$menu);
                    $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
                }
    		} else {
                Send($from_id,"▪️کاربر <a href='tg://user?id=$from_id'>$first</a>\nبه ربات <a href='https://t.me/$unb'>$fnb</a> خوش آمدید🎗\n\nتوسط این ربات میتوانید از خدمات اینستاگرام #رایگان از جمله لایک و فالوور برخوردار شوید‼️",'html',true,$message_id,$menu);
                $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
            }
        } else {
            Send($from_id,'شما نمیتوانید خودتان را به ربات دعوت نمایید !',null,null,$message_id,$menu);
        }
	} else {
        if($users['userid'] == false){
            if($users['phone'] == '0' || $users['phone'] == false){
                Send($from_id,'برای تایید شماره شما جهت مقابله با کاربران فیک (مجازی) شماره خود را توسط کیبورد زیر به اشتراک بگذارید〽️
✳️ توجه : شماره شما نزد ما امن میماند و برای کسی فاش نمیشود‼️',null,null,$message_id,json_encode(['keyboard'=>[[['text'=>'تایید شماره +98 💯','request_contact'=>true]]],'resize_keyboard'=>true,'one_time_keyboard'=>true]));
                $connect->query("INSERT INTO `users` (`userid`,`phone`,`command`,`free_likes`,`free_followers`,`likes`,`followers`,`block`) VALUES ('$from_id','0','phone confirm-me','50','20','0','0','false')");
            } else {
                Send($from_id,"▪️کاربر <a href='tg://user?id=$from_id'>$first</a>\nبه ربات <a href='https://t.me/$unb'>$fnb</a> خوش آمدید🎗\n\nتوسط این ربات میتوانید از خدمات اینستاگرام #رایگان از جمله لایک و فالوور برخوردار شوید‼️",'html',true,$message_id,$menu);
                $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
            }
		} else {
            if($users['phone'] == '0' || $users['phone'] == false){
                Send($from_id,'برای تایید شماره شما جهت مقابله با کاربران فیک (مجازی) شماره خود را توسط کیبورد زیر به اشتراک بگذارید〽️
✳️ توجه : شماره شما نزد ما امن میماند و برای کسی فاش نمیشود‼️',null,null,$message_id,json_encode(['keyboard'=>[[['text'=>'تایید شماره +98 💯','request_contact'=>true]]],'resize_keyboard'=>true,'one_time_keyboard'=>true]));
                $connect->query("INSERT INTO `users` (`userid`,`phone`,`command`,`free_likes`,`free_followers`,`likes`,`followers`,`block`) VALUES ('$from_id','0','phone confirm-me','50','20','0','0','false')");
            } else {
                Send($from_id,"▪️کاربر <a href='tg://user?id=$from_id'>$first</a>\nبه ربات <a href='https://t.me/$unb'>$fnb</a> خوش آمدید🎗\n\nتوسط این ربات میتوانید از خدمات اینستاگرام #رایگان از جمله لایک و فالوور برخوردار شوید‼️",'html',true,$message_id,$menu);
                $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
            }
		}
	}
}
##----------[Phone Confirm]----------##
else if(preg_match('/^(phone confirm-(.*))/',$users['command']) &&  isset($update->message->contact) && !in_array($message,$no_send)){
    preg_match('/^(phone confirm-(.*))/',$users['command'],$match);
    $phone_number =	$update->message->contact->phone_number;
    if($update->message->contact->user_id == $from_id){
        if(substr($phone_number,0,-10) == '98'){
            if($match[2] == 'me'){
                $connect->query("UPDATE `users` SET `phone` = '$phone_number' WHERE `userid` = '$from_id'");
                $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
                Send($from_id,'شماره شما تایید شد🔥');
                Send($from_id,'از اول استارت نمایید ✌️
/start',null,null,$message_id,$remove);
            } else {
                $users2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `users` WHERE `userid` = '$match[2]'"));
                $likess = $users2['likes'];
                $followerss = $users2['followers'];
                $flwo = $followerss + 10;
                $lke = $likess + 15;
                $connect->query("UPDATE `users` SET `followers` = '$flwo'  WHERE `userid` = '$match[2]'");
                $connect->query("UPDATE `users` SET `likes` = '$lke'  WHERE `userid` = '$match[2]'");
                Send($match[2],'یک نفر توسط شما عضو ربات شد و شما 10 موجودی فالوور و 15 موجودی لایک دریافت کردید 🎗',null,null,null,$menu);  
                $connect->query("UPDATE `users` SET `phone` = '$phone_number' WHERE `userid` = '$from_id'");
                $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
                Send($from_id,'شماره شما تایید شد🔥');
                Send($from_id,'از اول استارت نمایید ✌️
/start',null,null,$message_id,$remove);
            }
		} else {
            Send($from_id,'فقط کاربران ایرانی با پیش شماره +98 توانایی استفاده از ربات را دارند ‼️️',null,null,$message_id,$remove);
            $connect->query("DELETE FROM `users` WHERE `userid` = '$from_id'");
        }
	} else {
        Send($from_id,'برای تایید شماره شما جهت مقابله با کاربران فیک (مجازی) شماره خود را توسط کیبورد زیر به اشتراک بگذارید〽️
✳️ توجه : شماره شما نزد ما امن میماند و برای کسی فاش نمیشود‼️',null,null,$message_id,json_encode(['keyboard'=>[[['text'=>'تایید شماره +98 💯','request_contact'=>true]]],'resize_keyboard'=>true,'one_time_keyboard'=>true]));
    }
}
##----------[lock channel]----------##
else if(!in_array($tch_1,$join) and $kanal[0] || !in_array($tch_2,$join) and $kanal[1]){
    $link_1 = str_replace('@',null,$kanal[0]);
    $link_2 = str_replace('@',null,$kanal[1]);
    Send($from_id,'سلام🌹
🔸جهت حمایت و استفاده از ربات ما و همچنین اطلاع از بروز رسانی ها در کانال زیر عضو شوید و سپس گزینه 
/start
را بزنید.↖️',null,null,$message_id,json_encode(['inline_keyboard'=>[
        [['text'=>'عضویت〽 - 1️','url'=>'https://t.me/'.$link_1]],
        [['text'=>'عضویت〽 - 2️','url'=>'https://t.me/'.$link_2]],
    ]]));
    exit();
}
##----------[khadamat insta]----------##
else if($message == 'خدمات اینستاگرام 🦋 (رایگان)'){
    Send($from_id,'به بخش '.$message.' وارد شدید.
▪️ یک گزینه را انتخخاب نمایید :',null,null,$message_id,json_encode(['keyboard'=>[[['text'=>'لایک اینستاگرام ❤️'],['text'=>'فالوور اینستاگرام 👥']],[['text'=>'اطلاعات حساب👤']],[['text'=>'➡️']]],'resize_keyboard'=>true,'one_time_keyboard'=>true]));
}
##----------[get like]----------##
else if($message == 'لایک اینستاگرام ❤️'){
    if($users['free_likes'] >= '30'){
        $connect->query("UPDATE `users` SET `command` = 'get post_free' WHERE `userid` = '$from_id'");
        Send($from_id,'لینک پست مورد نظر خود را کپی و ارسال کنید :
توجه‼️ : دقت کنید حساب شما نباید خصوصی باشد.️',null,null,$message_id,$back);
    } else {
        if($users['likes'] >= '50'){
            $connect->query("UPDATE `users` SET `command` = 'get post_coin' WHERE `userid` = '$from_id'");
            Send($from_id,'لینک پست مورد نظر خود را کپی و ارسال کنید :
توجه‼️ : دقت کنید حساب شما نباید خصوصی باشد.',null,null,$message_id,$back);
        } else {
            Send($from_id,'شما کمتر از 50 لایک موجودی دارید و امکان ثبت لایک برای شما مقدور نیست !',null,null,$message_id,$back);
        }
	}
}
//=====
else if(preg_match('/^(get post_(.*))/i',$users['command']) && !in_array($message,$no_send)){
    preg_match('/^(get post_(.*))/i',$users['command'],$match);
    $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
    if(preg_match('/^(https:\/\/www\.instagram.com\/p\/.{11})/',$message)){
        if($match[2] == 'coin'){
            $new_like = $users['likes'] - 50;
            $connect->query("UPDATE `users` SET `likes` = '$new_like' WHERE `userid` = '$from_id'");
        } else {
            $new_like = $users['free_likes'] - 30;
            $connect->query("UPDATE `users` SET `free_likes` = '$new_like' WHERE `userid` = '$from_id'");
        }
        Send($from_id,'🔄 در حال بارگیری عکس مورد نظر .',null,null,$message_id);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری عکس مورد نظر ..','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری عکس مورد نظر ...','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری عکس مورد نظر .','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری عکس مورد نظر ..','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری عکس مورد نظر ...','reply_to_message_id'=>$message_id+1]);
        Project('SendPhoto',['chat_id'=>$from_id,'photo'=>$message,'caption'=>'تعداد لایک فعلی : '.$now_like,'reply_to_message_id'=>$message_id]);
        // حل قرار گیری وب سرویس لایک
        Send($from_id,'سفارش شما با موفقیت ثبت شد بزودی لایک هاتون ارسال خواهد شد🌹',null,null,$message_id);
    } else {
        Send($from_id,'خطا❗️
 ایدی خود را به درستی وارد نمایید !🌱',null,null,$message_id,$back);
    }
}
##----------[get follower]----------##
else if($message == 'فالوور اینستاگرام 👥'){
    if($users['free_likes'] >= '50'){
        $connect->query("UPDATE `users` SET `command` = 'get page_free' WHERE `userid` = '$from_id'");
        Send($from_id,'لطفا ایدی اینستاگرامی خود را بدون @ ارسال کنید :
توجه‼️ : دقت کنید حساب شما نباید خصوصی باشد.️',null,null,$message_id,$back);
    } else {
        if($users['likes'] >= '70'){
            $connect->query("UPDATE `users` SET `command` = 'get page_coin' WHERE `userid` = '$from_id'");
            Send($from_id,'لطفا ایدی اینستاگرامی خود را بدون @ ارسال کنید :
توجه‼️ : دقت کنید حساب شما نباید خصوصی باشد.️',null,null,$message_id,$back);
        } else {
            Send($from_id,'شما کمتر از 70 فالوور موجودی دارید و امکان ثبت فالوور برای شما مقدور نیست !',null,null,$message_id,$back);
        }
	}
}
//=====
else if(preg_match('/^(get page_(.*))/i',$users['command']) && !in_array($message,$no_send)){
    preg_match('/^(get page_(.*))/i',$users['command'],$match);
    $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
    $api = json_decode(file_get_contents('https://'.$_SERVER['HTTP_HOST'].'/'.str_replace('bot','insta',$_SERVER['SCRIPT_NAME']).'?id='.$message),true);
    $token = $api['config']['csrf_token'];
    $id_followers = $api['entry_data']['ProfilePage'][0]['graphql']['user']['edge_followed_by']['count'];
    $profile = $api['entry_data']['ProfilePage'][0]['graphql']['user']['profile_pic_url_hd'];
    if($token != null){
        if($match[2] == 'coin'){
            $new_follower = $users['followers'] - 70;
            $connect->query("UPDATE `users` SET `followers` = '$new_follower' WHERE `userid` = '$from_id'");
        } else {
            $new_follower = $users['free_followers'] - 50;
            $connect->query("UPDATE `users` SET `free_followers` = '$new_follower' WHERE `userid` = '$from_id'");
        }
        Send($from_id,'🔄 در حال بارگیری پیج مورد نظر .',null,null,$message_id);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری پیج مورد نظر ..','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری پیج مورد نظر ...','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری پیج مورد نظر .','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری پیج مورد نظر ..','reply_to_message_id'=>$message_id+1]);
        sleep(1);
        Project('editMessagetext',['chat_id'=>$from_id,'message_id'=>$message_id+1,'text'=>'🔄 در حال بارگیری پیج مورد نظر ...','reply_to_message_id'=>$message_id+1]);
        Project('SendPhoto',['chat_id'=>$from_id,'photo'=>$profile,'caption'=>'تعداد فالوور فعلی : '.$id_followers,'reply_to_message_id'=>$message_id]);
        // مجل قرار گیری وب سرویس فالوور
        Send($from_id,'سفارش شما با موفقیت ثبت شد بزودی فالوور هاتون ارسال خواهد شد🌹',null,null,$message_id);
    } else {
        Send($from_id,'خطا❗️
 ایدی خود را به درستی وارد نمایید !🌱',null,null,$message_id,$back);
    }
}
/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/
##----------[my info]----------##
else if($message == 'اطلاعات حساب👤'){
    $last=$update->message->from->last_name;
    $username=$update->message->from->username;
    $a=$users['followers'];
    $b=$users['free_followers'];
    $c=$users['likes'];
    $d=$users['free_likes'];
    Send($from_id,'اطلاعات حساب شما به شرح زیر است 👇',null,null,$message_id,json_encode(['inline_keyboard'=>[
        [['text'=>': نام کوچک','callback_data'=>'null'],['text'=>"$first",'callback_data'=>'null']],
        [['text'=>': نام خانوادگی','callback_data'=>'null'],['text'=>"$last",'callback_data'=>'null']],
        [['text'=>': نام کاربری','callback_data'=>'null'],['text'=>'@'.$username,'url'=>'https://t.me/'.$username]],
        [['text'=>': شناسه','callback_data'=>'null'],['text'=>"$from_id",'callback_data'=>'null']],
        [['text'=>': مقدار فالوور','callback_data'=>'null'],['text'=>$a,'callback_data'=>'null']],
        [['text'=>': مقدار فالوور رایگان','callback_data'=>'null'],['text'=>$b,'callback_data'=>'null']],
        [['text'=>': مقدار لایک','callback_data'=>'null'],['text'=>$c,'callback_data'=>'null']],
        [['text'=>': مقدار لایک رایگان','callback_data'=>'null'],['text'=>$d,'callback_data'=>'null']],
    ]]));
    Send($from_id,'برای بازگشت به منوی اصلی از کیبورد زیر استفاده نمایید ',null,null,$message_id,$back);
}
##----------[buy like]----------##
else if($message == 'خرید لایک اینستاگرام ❤️'){
    Send($from_id,'یکی از بسته های لایک زیر را انتخاب کنید و پس از انجام مراحل پرداخت مقدار لایک ها به حساب شما واریز میگردد‼️️',null,null,$message_id,json_encode(['inline_keyboard'=>[
        [['text'=>'100 ❤️ | 400 تومان','url'=>pay($from_id,400,'خرید بسته لایک اینستاگرام ربات رویال سرویس')]],
    ]]));
    Send($from_id,'⚠️امن و تحت نظارت بانک مرکزی⚠️',null,null,$message_id+1,$back);
}
##----------[buy follower]----------##
else if($message == 'خرید فالوور اینستاگرام 👤'){
    Send($from_id,'یکی از بسته های فالوور زیر را انتخاب کنید و پس از انجام مراحل پرداخت مقدار فالوور ها به حساب شما واریز میگردد‼️️',null,null,$message_id,json_encode(['inline_keyboard'=>[
        [['text'=>'100 👤 | 700 تومان','url'=>pay($from_id,700,'خرید بسته فالوور اینستاگرام ربات رویال سرویس')]],
    ]]));
    Send($from_id,'⚠️امن و تحت نظارت بانک مرکزی⚠️',null,null,$message_id+1,$back);
}
##----------[page info]----------##
else if($message == 'اطلاعات اکانت اینستاگرام🗄'){
    $connect->query("UPDATE `users` SET `command` = 'page info' WHERE `userid` = '$from_id'");
    Send($from_id,'⚠️ لطفا آیدی اینستاگرامی خود را بدون @ ارسال نمایید :',null,null,$message_id,$back);
}
//=====
else if($users['command'] == 'page info' && !in_array($message,$no_send)){
    $connect->query("UPDATE `users` SET `command` = 'null' WHERE `userid` = '$from_id'");
    $api = json_decode(file_get_contents('https://'.$_SERVER['HTTP_HOST'].'/'.str_replace('bot','insta',$_SERVER['SCRIPT_NAME']).'?id='.$message),true)['entry_data']['ProfilePage'][0]['graphql']['user'];
    $token = json_decode(file_get_contents('https://'.$_SERVER['HTTP_HOST'].'/'.str_replace('bot','insta',$_SERVER['SCRIPT_NAME']).'?id='.$message),true)['config']['csrf_token'];
    if($token != null){
        $followers = $api['edge_followed_by']['count'];
        $following = $api['edge_follow']['count'];
        $account_name = $api['full_name'];
        $account_bio = $api['biography'];
        $account_username = $api['username'];
        $profile_photo = $api['profile_pic_url_hd'];
        Project('SendPhoto',['chat_id'=>$from_id,'photo'=>$profile_photo,'caption'=>"🔐 اطلاعات حساب $message به صورت زیر میباشد :
👤 نام صاحب اکانت : $account_name
🖇 بیوگرافی صاحب اکانت : $account_bio
📍 یوزرنیم اکانت : $account_username
👥 تعداد فالوور های اکانت : $followers
‼️تعداد فالیینگ های اکانت : $following",'reply_markup'=>json_encode(['inline_keyboard'=>[
            [['text'=>'رفتن به پیج '.$message,'url'=>'https://instagram.com/'.$message]],
        ]])]);
    } else {
        Send($from_id,'چنین اکانتی در اینستاگرام وجود ندارد !!',null,null,$message_id,$back);
    }
}
##----------[banner]----------##
else if($message == 'زیرمجموعه گیری👨‍👧‍👦'){
    $hash = base64_encode($from_id);
    Project('SendPhoto',['chat_id'=>$from_id,'photo'=>new CURLFile('banner.jpg'),'caption'=>'🔅 افزایش فالوور و لایک اکانت خود به سادگی لمس لینک زیر 👌👇'."\n".'🔥کاملا رایگان و واریز سریع'."\n".'⭕️ https://t.me/'.Project('getme')->result->username.'?start=inv_'.$hash,'reply_markup'=>$back]);
}
##----------[support]----------##
else if($message == 'پشتیبانی🗣'){
    Send($from_id,'متن خود را در قالب پیام ارسال نمایید تا در اسرع وقت پاسخ داده شود :',null,null,$message_id,$back);
    $connect->query("UPDATE `users` SET `command` = 'support' WHERE `users`.`userid` = '$from_id'");
}
//===
else if($users['command'] == 'support' && !in_array($message,$no_send)){
    $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
    Send($admins[0],'شما یک پیام دارید جدید دریافت کردید !'."\n".'متن پیام :'."\n".$message,null,null,null,json_encode(['inline_keyboard'=>[
        [['text'=>'اطلاعات کاربر👤','callback_data'=>'info_'.$from_id],['text'=>'پاسخ به کاربر🗣','callback_data'=>'ans_'.$from_id]],
        [['text'=>'بلاک کردن✖️','callback_data'=>'block_'.$from_id]],
    ]]));
    Send($from_id,'پیام شما به دست مدیر رسید✔️ ',null,null,$message_id,$back);
}
//===
else if(preg_match('/^(info_(.*))/',$message)){
    preg_match('/^(info_(.*))/',$message,$match);
    $id = $match[2];
    $first = Project('getChat',['chat_id'=>$id])->result->first_name;
    Send($from_id,"کاربر : <a href='tg://user?id=$id'>$first</a>",'html',true,$message_id);
}
//===
else if(preg_match('/^(ans_(.*))/',$message)){
    preg_match('/^(ans_(.*))/',$message,$match);
    $id = $match[2];
    $connect->query("UPDATE `users` SET `command` = 'support_$id' WHERE `users`.`userid` = '$from_id'");
    Send($admins[0],"شما در حال چت با کاربر : <a href='tg://user?id=$id'>$id</a> هستید!\nپیام خود را در قالب یک متن ارسال کنید",'html',true,null,$back);
}
//===
else if(preg_match('/^(support_(.*))/',$users['command']) && !in_array($message,$no_send)){
    preg_match('/^(support_(.*))/',$users['command'],$match);
    $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
    Send($match[2],'پیامی از طرف مدیریت دارید!\nمتن پیام شما :'."\n".$message);
    Send($admins[0],"پیام شما به کاربر :  <a href='tg://user?id=$match[2]'>$match[2]</a> رسید !",'html',true,null,$back_menu);
}
//===
else if(preg_match('/^(block_(.*))/',$message)){
    preg_match('/^(block_(.*))/',$message,$match);
    $id = $match[2];
    $connect->query("UPDATE `users` SET `block` = 'true' WHERE `users`.`userid` = '$id'");
    Send($admins[0],"کاربر <a href='tg://user?id=$id'>$id</a> با موفقیت بلاک شد!",'html',true,$message_id,$back);
    Send($id,'شما از ربات بلاک شدید⁉️',null,null,null,$remove);
}
##----------[help]----------##
else if($message == 'راهنما ⚠️'){
    Send($from_id,'🔆 راهنمای ربات :
ما برای جلب رضایت کاربران با ورود ربات به حساب شما 20 موجودی فالوور و 50 موجودی لایک به حساب شما واریز میشود♥️
🔆 زیر مجموعه گیری در ربات :
 شما با دریافت لینک شخصی خودتون و فرستادن برای دوستانتون با ورود هر نفر به ربات از طریق لینک خصوصی شما 10 موجودی فالور و 15 موجودی لایک دریافت میکنید ♥️',null,null,$message_id,$back);
}
##----------[panel managmaent]----------##
else if(in_array($from_id,$admins)){
	if(in_array($message,['/panel','من','↪️'])){
        $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'مدیر گرامی به پنل مدیریت ربات خوش آمدید',null,null,$message_id,$panel);
    }
    ##----------[amar]----------##
    else if($message == 'آمار📈'){
        $users = mysqli_num_rows(mysqli_query($connect, "SELECT `userid` FROM `users`"));
        Send($from_id,'تعداد کاربران : '.$users,null,null,$message_id,$panel);
    }
    ##----------[user info]----------##
    else if($message == 'اطلاعات کاربر🔐'){
        $connect->query("UPDATE `users` SET `command` = 'user_info' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'ایدی عددی کاربر مورد نظر را ارسال نمایید :',null,null,$message_id,$back2);
    }
	//=====
    else if($users['command'] == 'user_info' && !in_array($message,$no_send)){
        $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
        @$users2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `users` WHERE `userid` = '$message'"));
        @$phone = $users2['phone'];
        @$free_likes = $users2['free_likes'];
        @$free_followers = $users2['free_followers'];
        @$likes = $users2['likes'];
        @$followers = $users2['followers'];
        @$block = $users2['block'];
        Send($from_id,"🔐 اطلاعات کاربر مورد نظر به صورت زیر میباشد :
شماره تلفن کاربر : $phone
مقدار لایک رایگان : $free_likes
مقدار لایک اصلی : $likes
نقدار فالوور رایگان : $free_followers
مقدار فالوور اصلی : $followers
وضعیت بلاکی : $block\n",null,null,$message_id,$back2);
    }
    ##----------[forward]----------##
    else if($message == 'فوروارد📩'){
        $connect->query("UPDATE `users` SET `command` = 'forward' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'پیام مورد نظر خود را برای فوروارد ارسال نمایید :',null,null,$message_id,$back2);
    }
	//=====
    else if($users['command'] == 'forward' && !in_array($message,$no_send)){
        $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'با موفقیت به همه اعضا فوروارد شد  :)',null,null,$message_id,$back2);
        @$querycheckssa = mysqli_query($connect,"SELECT * FROM `users`");
        while($users2 = mysqli_fetch_assoc($querycheckssa)){
            $all = $users2['userid'];
            Project('ForwardMessage',['chat_id'=>$all,'from_chat_id'=>$from_id,'message_id'=>$message_id]);
        }
	}
    ##----------[send]----------##
    else if($message == 'ارسال🏮'){
        $connect->query("UPDATE `users` SET `command` = 'send_all' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'پیام مورد نظر خود را برای فوروارد ارسال نمایید :',null,null,$message_id,$back2);
    }
    //=====
    else if($users['command'] == 'send_all' && !in_array($message,$no_send)){
        $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'با موفقیت به همه ارسال شد :)',null,null,$message_id,$back2);
        @$querycheckssa = mysqli_query($connect,"SELECT * FROM `users`");
        while($users2 = mysqli_fetch_assoc($querycheckssa)){
            $all = $users2['userid'];
            Send($all,$message);
        }
	}
    ##----------[BLOCK USER]----------##
    else if($message == 'بلاک💤'){
        $connect->query("UPDATE `users` SET `command` = 'block-user' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'ایدی عددی کاربر مورد نظر را جهت بلاک ارسال نمایید : ',null,null,$message_id,$back2);
    }
	//=====
    else if($users['command'] == 'block-user' && !in_array($message,$no_send)){
        $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
        @$users2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `users`  WHERE `userid` = '$message';"));
        $blcokcheck = $users2['block'];
        if($blcokcheck == 'false'){
            $connect->query("UPDATE `users` SET `block` = 'true' WHERE `users`.`userid` = '$message'");
            Send($from_id,'کاربر مورد نظر با موفقیت بلاک شد!',null,null,$message_id,$back2);
            Send($message,'شما توسط مدیران ربات بلاک شدید!',null,null,null,$remove);
        } else {
            Send($from_id,'کاربر مورد نظر از قبل بلاک میباشد !',null,null,$message_id,$back2);
        }
	}
    ##----------[UNBLOCK USER]----------##
    else if($message == 'آنبلاک☀️'){
        $connect->query("UPDATE `users` SET `command` = 'unblock-user' WHERE `users`.`userid` = '$from_id'");
        Send($from_id,'ایدی عددی کاربر مورد نظر را جهت آنبلاک ارسال نمایید : ',null,null,$message_id,$back2);
    }
    //=====
    else if($users['command'] == 'unblock-user' && !in_array($message,$no_send)){
        $connect->query("UPDATE `users` SET `command` = 'null' WHERE `users`.`userid` = '$from_id'");
        @$users2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `users`  WHERE `userid` = '$message';"));
        $blcokcheck = $users2['block'];
        if($blcokcheck == 'true'){
            $connect->query("UPDATE `users` SET `block` = 'false' WHERE `users`.`userid` = '$message'");
            Send($from_id,'کاربر مورد نظر با موفقیت آنبلاک شد!',null,null,$message_id,$back2);
            Send($message,'شما توسط مدیران ربات آنبلاک شدید!',null,null,null,$menu_user);
        } else {
            Send($from_id,'کاربر مورد نظر از قبل آنبلاک میباشد !',null,null,$message_id,$back2);
        }
	}
    ##----------[ON BOT]----------##
    else if($message == 'روشن 📳'){
        if($pnl['power'] == 'OFF'){
            $connect->query("UPDATE `panel` SET `power` = 'ON'");
            Send($from_id,'ربات با موفقیت روشن شد!',null,null,$message_id,$panel);
        } else {
            Send($from_id,'ربات از قبل روشن بود!!!',null,null,$message_id,$panel);
        }
	}
    ##----------[OFF BOT]----------##
    else if($message == 'خاموش 📴'){
        if($pnl['power'] == 'ON'){
            $connect->query("UPDATE `panel` SET `power` = 'OFF'");
            Send($from_id,'ربات با موفقیت خاموش شد!',null,null,$message_id,$panel);
        } else {
            Send($from_id,'ربات از قبل خاموش بود!!!',null,null,$message_id,$panel);
        }
    }
    ##----------[End Source]----------##
}
/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/
?>