<?php
/*
● سورس ربات دریافت لایک و فالور اینستاگرام و فروش آن
● نویسنده : @DevCando,@DevTelePro
● کانال ما : @TeleProTM
● دیتابیس ربات : Mysqli
● لطفا با ذکر منبع کپی نمایید 
*/
ob_start();
error_reporting(0);

// database php version 7.0^
$servername = "localhost"; // localhost or host ip
$username = "###"; // یوزرنیم دیتابیس
$password = "####"; // پسورد دیتابیس
$dbname = "#####"; // اسم دیتابیس
$connect = new mysqli($servername, $username, $password, $dbname);

##----------[Bot Config]----------##
define('API_KEY','توکن ربات');
$MerchantID = 'مرچند ایدی';
$admins = array('ایدی عددی ادمین ها');
$kanal = array('یوزرنیم کانال ها همراه @');
$join = array('member','administrator','creator'); // دست نزنید
$no_send = array('/start','/panel','➡️','↪️','من'); // دست نزنید